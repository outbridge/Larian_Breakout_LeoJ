#include "GameConfigLoader.h"

GameConfigLoader::GameConfigLoader()
{
}


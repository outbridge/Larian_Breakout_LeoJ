#pragma once
#include <glm/glm.hpp>

class GameConfigLoader
{
public:
    GameConfigLoader();
};
